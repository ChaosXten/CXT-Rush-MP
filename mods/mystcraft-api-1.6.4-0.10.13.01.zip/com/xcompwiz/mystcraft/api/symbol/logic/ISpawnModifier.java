package com.xcompwiz.mystcraft.api.symbol.logic;

/**
 * Placeholder interface
 * @author xcompwiz
 */
public interface ISpawnModifier {
}